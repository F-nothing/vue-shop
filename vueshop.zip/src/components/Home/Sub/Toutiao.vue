<template>
    <!--<div class="scroll_news" style="margin: 0 0 .4rem 0;-->
    <!--border-radius: 0;position: absolute;-->
<!--overflow: hidden;height: 30px">-->
        <!--<a><img style="width: 72px;-->
    <!--height: 15px;" onerror="__reloadResource(this)" onload="firstImgLoaded()" src="//m.360buyimg.com/mobilecms/jfs/t14752/82/2574581467/6535/c8158ace/5aa8935bN94e31ff6.jpg.dpg"></a>-->


        <!--<div class="news_list_wrapper">-->
            <!--<ul class="news-list j_scroll_news" style="transform: translate3d(0px, 0px, 0px); transition: none;">-->





                <!--<li class="news_item">-->
                    <!--<a data-floor_id="5734" data-event_level="1" data-event_id="MHome_BJDNews" data-event_param="j_event_param" href="javascript:void(0);" jump-href="//pro.m.jd.com/mall/active/3vWapAz58pJGYRfNeG88ddfsMM8S/index.html?innerLink=%5B%7B%22innerAnchor%22%3A%22152555085%22%7D%2C%7B%22innerAnchor%22%3A%22151695475%22%7D%5D">-->
                        <!--<span class="j_event_param" style="display: none;">5734_1_CMSSH361153_0__0_1_1___152555085#2_________{"position":"18#1#2","style":"24","sourceid":"152555085","modbiinfo":"1#1#ABTest-10300-G3-27-ABTest-10299-S5-88#782562","moduleid":"361153","sourcetype":"10","floorid":"5734"}</span>-->
                        <!--<span class="red">HOT</span>破壁机搞定三餐，给你均衡营养！-->
                    <!--</a>-->
                <!--</li><li class="news_item">-->
                <!--<a data-floor_id="5734" data-event_level="1" data-event_id="MHome_BJDNews" data-event_param="j_event_param" href="javascript:void(0);" jump-href="//pro.m.jd.com/mall/active/3vWapAz58pJGYRfNeG88ddfsMM8S/index.html?innerLink=%5B%7B%22innerAnchor%22%3A%22151695475%22%7D%2C%7B%22innerAnchor%22%3A%22152555085%22%7D%5D">-->
                    <!--<span class="j_event_param" style="display: none;">5734_0_CMSSH361154_0__0_1_1___151695475#1_________{"position":"18#1#1","style":"24","sourceid":"151695475","modbiinfo":"1#1#ABTest-10300-G3-27-ABTest-10299-S5-88#782562","moduleid":"361154","sourcetype":"10","floorid":"5734"}</span>-->
                    <!--<span class="red">热门</span>6个重伤发动机的习惯，用不到5年则大修。-->
                <!--</a>-->
            <!--</li></ul>-->
        <!--</div>-->







    </div>

</template>
<script>
export default {

}
</script>
<style lang='stylus'>


</style>
