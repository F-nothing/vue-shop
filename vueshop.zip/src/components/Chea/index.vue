<template>
    <div class="cont">
         <chea></chea>
    </div>
</template>
<script>
import Chea from './Chea.vue'
export default {
    name: "index",
    components:{
        Chea,
    },
}
</script>

<style lang="stylus" scoped>



</style>
