# 前言
[README in English](README-en.md)
简介：本人目前高三，初学前端，首次基于vue开发的20多个单页面商城系统，适合vue初学者参考学习，本系统对登陆注册，购物车，vuex，
## 
因为是业余时间写的，难免有些bug，还请提出来谢谢哈    53746237@qq.com
## 技术栈
vue2.5 + vuex + vue-router + webpack+ES6/7 
## 项目运行
npm install 


npm run serve

npm run build
## 关于接口数据

接口暂时全部都是自己服务器接口，后端系统会在以后发布的

# 说明
>  如果对您有帮助，您可以点右上角 "Star" 支持一下 谢谢！ ^_^
# 效果演示
[查看demo请戳这里]("http://cangdu.org/elm/")（请用chrome手机模式预览）
### 移动端扫描下方二维码
<img src="https://github.com/bailicangdu/vue2-elm/blob/master/screenshots/ewm.png" width="250" height="250"/>


# 项目目标功能说明
- [x] 注册登陆 -- 完成
- [x] 购物车删除/搜索 -- 完成
- [x] 商品页 -- 完成
- [x] 搜索页，分类搜索 -- 完成
- [ ] 个人中心 -- 等几天
- [ ] 下单功能 -- 等几天
- [ ] 添加删除修改收货地址 -- 等几天
# 总结


# 最终目标
1.


构建一个横跨前后端，移动IOS、Android的完整生态圈。


。。。敬请期待  

2019年1月26日 开开心心的
# 部分截图
### 商铺筛选页
<img src="https://github.com/bailicangdu/vue2-elm/blob/master/screenshots/food.png" width="365" height="619"/> <img src="https://github.com/bailicangdu/vue2-elm/blob/master/screenshots/food.gif" width="365" height="619"/>



#联系方式
<p>QQ请扫码(推荐)</p>
<img src="http://plxafm4ry.bkt.clouddn.com/qrcode_1548479224302.jpg" width="200" height="300">
<p>微信请扫码</p>
<img src="http://plxafm4ry.bkt.clouddn.com/mmqrcode1548479364570.png" width="250" height="250">

